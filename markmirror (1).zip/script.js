(function(){
/* ---------- data ---------- */
var SUBJ=[{c:"MA201",n:"Mathematics",cr:4,d:0},{c:"CS202",n:"DBMS",cr:4,d:-2},{c:"CS203",n:"Operating Systems",cr:3,d:-14},{c:"CS204",n:"Computer Networks",cr:3,d:-4},{c:"CS205",n:"Software Engineering",cr:3,d:2},{c:"CS206",n:"AI Lab",cr:3,d:8}];
var GP={"O":10,"A+":9,"A":8,"B+":7,"B":6,"C":5,"F":0};
var BR=["CSE","ECE","IT"];
var REEVAL_FEE=500;
function grade(t){return t>=90?"O":t>=80?"A+":t>=70?"A":t>=60?"B+":t>=50?"B":t>=40?"C":"F"}
var seed=7;function rnd(){seed=(seed*1664525+1013904223)%4294967296;return seed/4294967296}
function gauss(){return (rnd()+rnd()+rnd()+rnd()-2)*1.6}
var FN=["Aarav","Ananya","Karthik","Sneha","Rohit","Divya","Sai","Meera","Arjun","Pooja","Vikram","Lavanya","Nikhil","Harini","Rahul","Keerthi","Varun","Sowmya","Manoj","Priya"];
var LN=["Reddy","Sharma","Rao","Kumar","Naidu","Patel","Iyer","Goud","Verma","Chowdary"];
var S=[],counts={CSE:40,ECE:30,IT:30};
BR.forEach(function(b){for(var i=0;i<counts[b];i++){
 var ab=68+gauss()*13,t=SUBJ.map(function(s){var v=Math.round(Math.max(18,Math.min(99,ab+s.d+gauss()*9)));var i1=Math.round(v*0.4+gauss()*1.5);i1=Math.max(8,Math.min(40,i1));return{t:v,i:i1,e:v-i1}});
 S.push({ht:"22"+b+(101+i),name:FN[Math.floor(rnd()*20)]+" "+LN[Math.floor(rnd()*10)],br:b,m:t,hist:[0,1,2].map(function(){return Math.max(5,Math.min(9.9,ab/10+0.4+gauss()*0.5))})})}});
/* fixed demo student: SGPA 8.85 */
var demo=S.filter(function(s){return s.ht==="22CSE104"})[0];
demo.name="Ananya Reddy";demo.m=[86,84,75,88,76,93].map(function(v){var i=Math.round(v*.4);return{t:v,i:i,e:v-i}});demo.hist=[8.6,8.9,9.0];
function calc(s){var pts=0,cr=0,earned=0;s.rows=s.m.map(function(m,i){var g=grade(m.t),sub=SUBJ[i];pts+=sub.cr*GP[g];cr+=sub.cr;if(g!=="F")earned+=sub.cr;return{sub:sub,m:m,g:g,gp:GP[g],pass:g!=="F"}});
 s.sgpa=pts/cr;s.cr=cr;s.earned=earned;s.allpass=s.rows.every(function(r){return r.pass});
 s.cgpa=(s.hist.reduce(function(a,b){return a+b},0)+s.sgpa)/(s.hist.length+1)}
S.forEach(calc);
var byHT={};S.forEach(function(s){byHT[s.ht]=s});
function f2(x){return x.toFixed(2)}
function esc(t){return String(t).replace(/[&<>"']/g,function(c){return"&#"+c.charCodeAt(0)+";"})}
function Phi(z){var t=1/(1+.2316419*Math.abs(z)),d=.3989423*Math.exp(-z*z/2),p=d*t*(.3193815+t*(-.3565638+t*(1.781478+t*(-1.821256+t*1.330274))));return z>0?1-p:p}
document.getElementById("hts").innerHTML=S.map(function(s){return'<option value="'+s.ht+'">'}).join("");

/* ---------- batch stats (computed once) ---------- */
var stats=SUBJ.map(function(sub,i){var p=0,sum=0;S.forEach(function(s){if(s.rows[i].pass)p++;sum+=s.rows[i].gp});
 var pr=p/S.length*100,avg=sum/S.length;return{n:sub.n,pass:pr,avg:avg,diff:(100-pr)*0.6+(1-avg/10)*100*0.4}});
var gdist={};Object.keys(GP).forEach(function(g){gdist[g]=0});S.forEach(function(s){s.rows.forEach(function(r){gdist[r.g]++})});
var bins=["Below 6","6-7","7-8","8-9","9-10"],bc=[0,0,0,0,0];
S.forEach(function(s){var c=s.cgpa;bc[c<6?0:c<7?1:c<8?2:c<9?3:4]++});

/* ---------- tabs ---------- */
var drawn=false;
document.querySelectorAll("nav button").forEach(function(b){b.onclick=function(){
 document.querySelectorAll("nav button").forEach(function(x){x.setAttribute("aria-selected",x===b)});
 document.querySelectorAll("main>section").forEach(function(s){s.hidden=s.id!==b.dataset.t});
 if(b.dataset.t==="analytics"&&!drawn){drawCharts();drawn=true}if(b.dataset.t==="compare"&&!cdrawn){drawCmp();cdrawn=true}}});
var cdrawn=false,tabs=[].slice.call(document.querySelectorAll("nav button"));
document.querySelector("nav").onkeydown=function(e){var i=tabs.indexOf(document.activeElement);if(i<0||(e.key!=="ArrowRight"&&e.key!=="ArrowLeft"))return;var n=tabs[(i+(e.key==="ArrowRight"?1:tabs.length-1))%tabs.length];n.focus();n.click()};

/* ---------- lookup ---------- */
var out=document.getElementById("out"),err=document.getElementById("err"),ht=document.getElementById("ht");
["22CSE104","22ECE110","22IT125"].forEach(function(h){var c=document.createElement("span");c.className="chip";c.textContent=h;c.tabIndex=0;
 c.onclick=function(){ht.value=h;show()};c.onkeydown=function(e){if(e.key==="Enter")c.click()};document.getElementById("chips").appendChild(c)});
function show(){var k=ht.value.trim().toUpperCase(),s=byHT[k];err.textContent="";out.innerHTML="";
 if(!s){err.textContent="No result found for “"+k+"”. Hall tickets look like 22CSE101 to 22CSE140, 22ECE101 to 22ECE130 or 22IT101 to 22IT130.";return}
 var rank=S.filter(function(x){return x.br===s.br}).sort(function(a,b){return b.sgpa-a.sgpa}).map(function(x){return x.ht}).indexOf(s.ht)+1;
 var dist=s.allpass&&s.sgpa>=8.5,br=S.filter(function(x){return x.br===s.br}),pct=Math.max(1,100-Math.round(br.filter(function(x){return x.sgpa<s.sgpa}).length/br.length*100));
 var rows=s.rows.map(function(r){return"<tr><td>"+r.sub.c+"</td><td>"+r.sub.n+"</td><td class='n'>"+r.sub.cr+"</td><td class='n'>"+r.m.i+"/40</td><td class='n'>"+r.m.e+"/60</td><td class='n'>"+r.m.t+"</td><td class='"+(r.pass?"":"F")+"'>"+r.g+"</td><td class='n'>"+r.gp+"</td></tr>"}).join("");
 var hist=s.hist.map(function(v,i){return"Sem "+(i+1)+": "+f2(v)}).join(" · ");
 out.innerHTML='<div id="sheet"><h3>Examination Result: Semester IV</h3><p class="sub">B.Tech Regular Examinations, Provisional Marksheet</p>'+
 '<div class="meta"><div>Name: <b>'+esc(s.name)+'</b></div><div>Hall ticket: <b>'+s.ht+'</b></div><div>Branch: <b>'+s.br+'</b></div><div>Branch rank: <b>'+rank+' of '+counts[s.br]+'</b></div><div>Standing: <b>Top '+pct+'% of branch</b></div><div>Batch: <b>2022</b></div></div>'+
 '<div class="tablewrap"><table><thead><tr><th>Code</th><th>Subject</th><th class="n">Credits</th><th class="n">Internal</th><th class="n">External</th><th class="n">Total</th><th>Grade</th><th class="n">Points</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
 '<div class="result"><span>SGPA: '+f2(s.sgpa)+'</span><span>CGPA: '+f2(s.cgpa)+'</span><span>Credits earned: '+s.earned+'/'+s.cr+'</span><span>'+(s.allpass?"PASS":"FAIL")+(dist?' <span class="badge">Distinction</span>':'')+'</span></div><p class="scale">Grade scale: O (90 and above) = 10, A+ (80) = 9, A (70) = 8, B+ (60) = 7, B (50) = 6, C (40) = 5, F (below 40) = 0. Pass mark: 40.</p></div>'+
 '<div class="row noprint" style="justify-content:center;margin-bottom:20px"><button class="btn" id="pr" type="button">Print or save as PDF</button></div>'+
 '<div class="card noprint"><h2>SGPA trend</h2><div class="canvasbox" style="height:240px"><canvas id="cTr"></canvas></div></div><div class="card noprint"><h2>You vs branch average</h2><div class="canvasbox" style="height:260px"><canvas id="cVs"></canvas></div></div>';
 document.getElementById("pr").onclick=function(){window.print()};
 new Chart(document.getElementById("cTr"),{type:"line",data:{labels:["Sem 1","Sem 2","Sem 3","Sem 4"],datasets:[{label:"SGPA",data:s.hist.map(function(v){return +f2(v)}).concat([+f2(s.sgpa)]),borderColor:"#0e6e8c",backgroundColor:"#0e6e8c",tension:.3}]},options:{maintainAspectRatio:false,scales:{y:{min:4,max:10}}}});
 new Chart(document.getElementById("cVs"),{type:"bar",data:{labels:SUBJ.map(function(x){return x.n}),datasets:[{label:"You",data:s.m.map(function(m){return m.t}),backgroundColor:"#0e6e8c"},{label:"Branch average",data:SUBJ.map(function(x,i){return Math.round(br.reduce(function(a,y){return a+y.m[i].t},0)/br.length)}),backgroundColor:"#e0a100"}]},options:{maintainAspectRatio:false,scales:{y:{max:100,title:{display:true,text:"Marks out of 100"}}}}});
 out.scrollIntoView({behavior:"smooth",block:"start"})}
document.getElementById("go").onclick=show;ht.onkeydown=function(e){if(e.key==="Enter")show()};

/* ---------- analytics ---------- */
function drawCharts(){
 var avgCg=S.reduce(function(a,s){return a+s.cgpa},0)/S.length,pa=S.filter(function(s){return s.allpass}).length;
 var worst=stats.slice().sort(function(a,b){return a.pass-b.pass})[0];
 document.getElementById("kpis").innerHTML=[[S.length,"students in batch"],[Math.round(pa/S.length*100)+"%","passed every subject"],[worst.n+" ("+Math.round(worst.pass)+"%)","lowest pass rate; batch mean CGPA "+f2(avgCg)]].map(function(k){return'<div class="card stat"><b>'+k[0]+'</b><span>'+k[1]+'</span></div>'}).join("");
 var o={maintainAspectRatio:false};
 new Chart(document.getElementById("cPass"),{type:"bar",data:{labels:stats.map(function(s){return s.n}),datasets:[{label:"Pass %",data:stats.map(function(s){return +s.pass.toFixed(1)}),backgroundColor:stats.map(function(s){return s.pass===worst.pass?"#c0392b":"#0e6e8c"})},{label:"Fail %",data:stats.map(function(s){return +(100-s.pass).toFixed(1)}),backgroundColor:"#e0a100"}]},options:{maintainAspectRatio:false,scales:{y:{max:100,title:{display:true,text:"% of students"}}}}});
 var gk=Object.keys(GP);
 new Chart(document.getElementById("cGrade"),{type:"doughnut",data:{labels:gk,datasets:[{data:gk.map(function(g){return gdist[g]}),backgroundColor:["#14213d","#0e6e8c","#2fa4a9","#8bc5a3","#e0a100","#e8884a","#c0392b"]}]},options:o});
 var cg=S.map(function(s){return s.cgpa}),mu=avgCg,sd=Math.sqrt(cg.reduce(function(a,v){return a+(v-mu)*(v-mu)},0)/cg.length),ed=[6,7,8,9],bell=[-1e9].concat(ed).map(function(lo,i){var hi=i<4?ed[i]:1e9;return +(S.length*(Phi((hi-mu)/sd)-Phi((lo-mu)/sd))).toFixed(1)});
 new Chart(document.getElementById("cHist"),{type:"bar",data:{labels:bins,datasets:[{label:"Students",data:bc,backgroundColor:"#0e6e8c",categoryPercentage:1,barPercentage:.95},{type:"line",label:"Normal curve",data:bell,borderColor:"#e0a100",backgroundColor:"#e0a100",tension:.4,pointRadius:3}]},options:{maintainAspectRatio:false,plugins:{legend:{display:true}},scales:{y:{title:{display:true,text:"Students"}},x:{title:{display:true,text:"CGPA range"}}}}})}

/* ---------- batch comparison ---------- */
function drawCmp(){var a=[];for(var i=0;i<100;i++){var ab=64+gauss()*13,pts=0,cr=0,ok=true;SUBJ.forEach(function(s){var g=grade(Math.round(Math.max(18,Math.min(99,ab+s.d+gauss()*9))));pts+=s.cr*GP[g];cr+=s.cr;if(g==="F")ok=false});a.push({sg:pts/cr,ok:ok})}
 var b=S.map(function(s){return{sg:s.sgpa,ok:s.allpass}});
 function sm(x){return{avg:x.reduce(function(t,v){return t+v.sg},0)/x.length,pass:x.filter(function(v){return v.ok}).length/x.length*100,top:Math.max.apply(null,x.map(function(v){return v.sg})),dist:x.filter(function(v){return v.ok&&v.sg>=8.5}).length}}
 function bn(x){var c=[0,0,0,0,0];x.forEach(function(v){c[v.sg<6?0:v.sg<7?1:v.sg<8?2:v.sg<9?3:4]++});return c.map(function(v){return +(v/x.length*100).toFixed(1)})}
 function row(l,x,y,u){var d=y-x;return'<tr><td>'+l+'</td><td class="n">'+x.toFixed(u)+'</td><td class="n">'+y.toFixed(u)+'</td><td class="n" style="color:var(--'+(d>=0?'ok':'bad')+')">'+(d>=0?'+':'')+d.toFixed(u)+'</td></tr>'}
 var p=sm(a),q=sm(b);
 document.getElementById("cmpT").innerHTML='<thead><tr><th>Metric</th><th class="n">2021 batch</th><th class="n">2022 batch</th><th class="n">Change</th></tr></thead><tbody>'+row("Average SGPA",p.avg,q.avg,2)+row("Passed all subjects (%)",p.pass,q.pass,0)+row("Highest SGPA",p.top,q.top,2)+row("Distinctions (SGPA 8.5+)",p.dist,q.dist,0)+'</tbody>';
 new Chart(document.getElementById("cCmp2"),{type:"bar",data:{labels:bins,datasets:[{label:"2021",data:bn(a),backgroundColor:"#e0a100"},{label:"2022",data:bn(b),backgroundColor:"#0e6e8c"}]},options:{maintainAspectRatio:false,scales:{y:{title:{display:true,text:"% of students"}},x:{title:{display:true,text:"SGPA range"}}}}})}

/* ---------- leaderboard ---------- */
var bt=document.getElementById("bt"),board=document.getElementById("board");
function lb(b){bt.querySelectorAll("button").forEach(function(x){x.setAttribute("aria-pressed",x.textContent===b)});
 var m=["🥇","🥈","🥉"];
 board.innerHTML=S.filter(function(s){return s.br===b}).sort(function(a,c){return c.sgpa-a.sgpa||c.earned-a.earned}).slice(0,10).map(function(s,i){return'<li><span class="medal">'+(m[i]||(i+1))+'</span><span><b>'+esc(s.name)+'</b><br><small style="color:var(--mut)">'+s.ht+'</small></span><span>SGPA <b>'+f2(s.sgpa)+'</b></span><span style="color:var(--mut)">'+s.earned+' credits</span></li>'}).join("")}
BR.forEach(function(b){var x=document.createElement("button");x.textContent=b;x.onclick=function(){lb(b)};bt.appendChild(x)});lb("CSE");

/* ---------- tools ---------- */
var rev=document.getElementById("rev");
function loadRev(){var s=byHT[document.getElementById("rht").value.trim().toUpperCase()];
 if(!s){rev.innerHTML='<p class="err">Enter a valid hall ticket first.</p>';return}
 rev.innerHTML='<p style="margin-top:0">'+esc(s.name)+'. Tick the papers you want rechecked (₹'+REEVAL_FEE+' per subject, sample rate).</p>'+s.rows.map(function(r,i){return'<label style="display:block;padding:4px 0"><input type="checkbox" class="rc" style="text-transform:none;min-width:auto;margin-right:8px"> '+r.sub.n+' <span style="color:var(--mut)">(grade '+r.g+')</span></label>'}).join("")+'<p><b>Total fee: <span id="tot">₹0</span></b></p>';
 rev.querySelectorAll(".rc").forEach(function(c){c.onchange=function(){document.getElementById("tot").textContent="₹"+rev.querySelectorAll(".rc:checked").length*REEVAL_FEE}})}
document.getElementById("rgo").onclick=loadRev;
document.getElementById("diff").innerHTML='<thead><tr><th>Subject</th><th class="n">Fail rate</th><th class="n">Avg grade point</th><th class="n">Difficulty</th></tr></thead><tbody>'+stats.slice().sort(function(a,b){return b.diff-a.diff}).map(function(s){return'<tr><td>'+s.n+'</td><td class="n">'+(100-s.pass).toFixed(0)+'%</td><td class="n">'+f2(s.avg)+'</td><td class="n"><b>'+s.diff.toFixed(0)+'</b></td></tr>'}).join("")+'</tbody>';
})();
